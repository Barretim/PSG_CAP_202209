﻿namespace MedVet.Poco
{
    public class Cidade
    {
        public Cidade()
        {
        }

        public int CodigoCidade { get; set; }

        public string Nome { get; set; } = null!;

        public int CodigoIBGE7 { get; set; }

        public int CodigoEstado { get; set; }
    }
}