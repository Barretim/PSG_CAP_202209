﻿namespace MedVet.Poco
{
    public class Estado
    {
        public Estado()
        {
        }

        public long CodigoEstado { get; set; }
        public string Nome { get; set; } = null!;
        public string UF { get; set; } = null!;
    }
}