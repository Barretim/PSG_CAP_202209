﻿namespace MedVet.Poco
{
    public class Convenio
    {
        public Convenio()
        {
        }

        public int CodigoConvenio { get; set; }

       public string Descricao { get; set; } = null!;

        public int Plano { get; set; }

        public decimal Tarifa { get; set; }

    }
}
